import cv2
import numpy as np


# Função para encontrar o centro de um retângulo
def centro_retangulo(retangulo):
    x, y, w, h = retangulo
    centro_x = x + (w // 2)
    centro_y = y + (h // 2)
    if centro_x > 400:
        angulo = ((centro_x-400)*60)/400
    elif centro_x < 400:
        angulo = 60-(centro_x*60)/400
        angulo = 0 - angulo
    else:
        angulo = 0
    print(angulo)
    return centro_x, centro_y
# Função para encontrar o ângulo em relação ao centro



# Inicializar a webcam
cap = cv2.VideoCapture(0)

# Variável global para armazenar o centro do retângulo sob o cursor do mouse
centro_retangulo_atual = None


# Função de callback para o evento do mouse


# Configurar o callback do mouse
cv2.namedWindow('Frame')


while True:

    # Capturar frame da webcam
    ret, frame = cap.read()

    largura_janela = 800
    altura_janela = 600
    imagem_redimensionada = cv2.resize(frame,(largura_janela,altura_janela))

    # Converter frame para espaço de cores HSV
    hsv = cv2.cvtColor(imagem_redimensionada, cv2.COLOR_BGR2HSV)

    # Definir o intervalo de cor azul em HSV
    lower_red = np.array([150, 100, 100])
    upper_red = np.array([179, 255, 255])

    # Criar uma máscara para filtrar apenas a cor azul
    mask = cv2.inRange(hsv, lower_red, upper_red)

    # Encontrar contornos na máscara
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Armazenar os retângulos
    retangulos = []

    # Iterar sobre os contornos encontrados
    for contour in contours:
        # Calcular a área do contorno
        area = cv2.contourArea(contour)

        # Se a área for maior que um valor mínimo, consideramos como nosso adesivo
        if area > 1000:
            # Encontrar retângulo delimitador ao redor do adesivo
            x, y, w, h = cv2.boundingRect(contour)

            # Desenhar retângulo ao redor do adesivo
            cv2.rectangle(imagem_redimensionada, (x, y), (x + w, y + h), (0, 255, 0), 2)
            for retangulo in retangulos:
                x_rect, y_rect, w_rect, h_rect = retangulo
                centro_retangulo(retangulo)
                cv2.waitKey(15)

            # Armazenar o retângulo
            retangulos.append((x, y, w, h))


    # Exibir o frame com o retângulo desenhado
    cv2.imshow('Frame', imagem_redimensionada)

    # Parar o loop quando a tecla 'q' for pressionada
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Liberar recursos
cap.release()
cv2.destroyAllWindows()
